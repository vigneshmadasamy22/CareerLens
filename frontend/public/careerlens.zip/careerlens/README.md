# CareerLens — AI-Powered Resume Builder, ATS Analyzer & Career Platform

[![FastAPI](https://img.shields.io/badge/FastAPI-0.110+-009688.svg?style=flat&logo=FastAPI&logoColor=white)](https://fastapi.tiangolo.com)
[![Next.js](https://img.shields.io/badge/Next.js-14.2+-black.svg?style=flat&logo=next.js&logoColor=white)](https://nextjs.org)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.6+-3178C6.svg?style=flat&logo=typescript&logoColor=white)](https://www.typescriptlang.org)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.4+-38B2AC.svg?style=flat&logo=tailwind-css&logoColor=white)](https://tailwindcss.com)
[![SQLAlchemy](https://img.shields.io/badge/SQLAlchemy-2.0+-D71F00.svg?style=flat&logo=sqlalchemy&logoColor=white)](https://www.sqlalchemy.org)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15+-4169E1.svg?style=flat&logo=postgresql&logoColor=white)](https://www.postgresql.org)

**CareerLens** is a production-quality, unified AI career suite combining a real-time **AI Resume Builder**, an explainable **ATS Resume Analyzer**, interactive **AI Mock Interviews**, and a **Career Application & Roadmap Tracker**.

Designed with pixel-perfect visual fidelity for both **Light Mode** and **Dark Mode**, matching high-end modern SaaS aesthetics with glassmorphic cards, glowing radial dials, and responsive layouts.

---

## 🌟 Key Modules & Capabilities

### 1. Main Dashboard
- **Executive Metrics**: Real-time KPI cards for Resumes Created (6), Analyses Done (14), Best ATS Score (87%), and Job Applications (8).
- **Career Progress Radial Gauge**: 78% overall progress ring with interactive milestone verification.
- **Recent Activity Feed**: Real-time timestamps and achievement score pills.
- **One-Click Quick Actions**: Create New Resume, Analyze Existing Resume, Match Resume with Job, and Prepare for Interview.

### 2. AI Resume Builder
- **20 Professional ATS-Friendly Templates**:
  - **Professional (4)**: Professional Elite, Corporate Clean, Executive Crest, Classic Standard
  - **Modern (4)**: Modern Pro, Neo Tech, Metro Horizon, Vibrant Edge
  - **Minimal (3)**: Minimal Clean, Pure Mono, Swiss Grid
  - **Creative (3)**: Creative Folio, Bold Canvas, Prism Studio
  - **Developer/Technical (3)**: Developer X, Dev Terminal, Git Commit
  - **Fresher/Student (3)**: Fresher Clean, Campus Prime, Intern Accelerator
- **Live Real-time A4 Editor**: Real-time side-by-side editing and rendering.
- **Customization Engine**: Live switching of template, font family (Inter, Roboto, Poppins, Merriweather), accent colors (Purple, Blue, Cyan, Emerald, Rose), font size, and section margins.
- **AI Writing Assistant**: Generates professional summaries, career objectives, and rewrites bullet points using the Google XYZ formula (*Accomplished [X] as measured by [Y], by doing [Z]*).
- **PDF & DOCX Export**: Real selectable-text A4/Letter PDF generation via ReportLab and native `.docx` export via `python-docx`.

### 3. AI Resume Analyzer & Job Matcher
- **Dual Ingestion**: Upload existing PDF/DOCX resumes or select from saved builder versions.
- **Real PDF & DOCX Parsing**: Powered by PyMuPDF (`fitz`), `pypdf`, and `python-docx` with intelligent section extraction.
- **Job Role & Target Employer Alignment**: Target custom job descriptions or predefined roles (Software Engineer, Full Stack, AI/ML, DevOps, Cloud).
- **Explainable ATS Match Score (out of 100)**:
  - Skills Match (90%)
  - Experience Relevance (82%)
  - Project Relevance (88%)
  - Keyword Coverage (86%)
  - Resume Readability (92%)
- **Categorized Keyword Breakdown**: Verified Matched (14), Missing (6) with natural placement advice, and Partial Matches (4).
- **Downloadable PDF ATS Report**: Complete audit report ready for offline review.

### 4. Low-Score Improvement Assistant
- **Score Optimization**: Visual progression tracking (Current Score 76 → Potential Score 92).
- **Priority-Ranked Action Cards**: High Priority (Summary & Keywords), Medium Priority (Project Enhancement), Low Priority (Grammar & Readability).
- **One-Click Apply**: Instantly incorporates suggested improvements into your draft.

### 5. AI Mock Interview Preparation
- **Categorized Practice Rooms**: Technical, HR & Behavioral, Project Architecture, and Mixed.
- **Interactive Simulator**: Question delivery, candidate answer input, and real-time AI scoring.
- **Detailed Evaluation Matrix**: Numerical score out of 10, identified strengths, targeted improvements, and recommended model answers.

### 6. Job Application Tracker
- **Pipeline Statistics**: 12 Total, 5 In Progress, 3 Interview, 2 Selected, 2 Rejected.
- **Interactive Kanban/Table**: Track Company, Role, Status Badges (Interview, Assessment, Applied, Selected, Rejected), Applied Date, Interview Date, and Notes.

### 7. Personalized Career Roadmap
- **Phased Skill Gap Roadmap**: Milestone timeline from Fundamentals & DSA to Next.js/FastAPI full-stack projects and placement interview readiness.
- **Radial Completion Gauge**: 68% progress visualization.

### 8. Advanced Features (Explore Suite)
- **Resume A/B Testing**: Compare two resume versions against the same job description.
- **Truth Checker**: Detects buzzwords, unsupported achievements, and claims lacking quantitative evidence.
- **Project Quality Analyzer**: Evaluates tech stack selection, system complexity, and impact metrics.
- **Skill Gap Analyzer**: Pinpoints missing competencies for target roles.
- **Recruiter Perspective Simulator**: Multi-agent evaluation from Recruiter (6-sec scan), Technical Interviewer, and Hiring Manager viewpoints.
- **Campus Placement Mode**: Specialized 1-page formatting and GPA/hackathon prioritization for freshers.

---

## 🏗️ Architecture

```
                    ┌────────────────────────────────────────┐
                    │      CareerLens Frontend (Next.js)     │
                    │  TypeScript • Tailwind CSS • Lucide UI │
                    │       Light Mode & Dark Mode Themes    │
                    └───────────────────┬────────────────────┘
                                        │ REST APIs & Rewrites
                                        ▼
                    ┌────────────────────────────────────────┐
                    │       CareerLens Backend (FastAPI)     │
                    │      Pydantic v2 • SQLAlchemy 2.0      │
                    └──────┬────────────┬────────────┬───────┘
                           │            │            │
            ┌──────────────▼─┐   ┌──────▼─────┐   ┌──▼─────────────┐
            │ ATS Scoring &  │   │ Parser &   │   │ Relational DB  │
            │ AI Engine      │   │ Exporter   │   │ SQLite /       │
            │ (Gemini/Rules) │   │ PyMuPDF    │   │ PostgreSQL     │
            │                │   │ ReportLab  │   │                │
            │                │   │ docx       │   │                │
            └────────────────┘   └────────────┘   └────────────────┘
```

---

## 🚀 Quick Start Guide

### Prerequisites
- **Node.js**: v18+ (tested on v24)
- **Python**: 3.11+

### Option 1: Double-Click Launcher (Windows)
Simply run:
```cmd
start-careerlens.bat
```
This automatically launches both the FastAPI backend and Next.js frontend in separate terminal windows!

### Option 2: Manual Development Setup

#### 1. Backend Setup
```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate
# Linux/macOS
source venv/bin/activate

pip install -r requirements.txt
python -m app.seed
uvicorn app.main:app --reload --port 8000
```
- API Docs: `http://127.0.0.1:8000/docs`

#### 2. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```
- Open browser at: `http://localhost:3000`

---

## 🧪 Automated Testing

To run the complete test suite:
```bash
cd backend
set PYTHONPATH=.
venv\Scripts\python.exe tests\test_direct.py
```
**Test Results:**
- Database entity integrity: **PASS**
- Explainable ATS scoring: **PASS**
- AI writing assistants & truth checker: **PASS**
- Real PDF export (>1KB selectable text): **PASS**
- Real DOCX export: **PASS**

---

## 🐳 Docker Deployment

Run the complete multi-container stack with PostgreSQL:
```bash
docker-compose up --build
```
- Frontend: `http://localhost:3000`
- Backend API: `http://localhost:8000`
- PostgreSQL: `localhost:5432`

---

## 👥 Default Demo Credentials
- **Email**: `vignesh@example.com`
- **Password**: `password123`
- Pre-populated with Vignesh Madasamy's primary resume, 12 tracked job applications, active ATS analysis for TCS, and personalized career roadmap!
