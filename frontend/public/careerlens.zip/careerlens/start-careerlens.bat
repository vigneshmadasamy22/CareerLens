@echo off
title CareerLens Platform Launcher
color 0B
echo =====================================================================
echo                CareerLens - AI Career Platform Launcher
echo =====================================================================
echo.

cd /d "%~dp0"

:: 1. Check Backend Environment
if not exist "backend\venv\Scripts\python.exe" (
    echo [Setup] Initializing Python Virtual Environment...
    python -m venv backend\venv
    echo [Setup] Installing backend dependencies...
    backend\venv\Scripts\pip.exe install -r backend\requirements.txt
)

:: 2. Check Frontend Dependencies
if not exist "frontend\node_modules" (
    echo [Setup] Installing frontend npm dependencies...
    cd frontend && npm install && cd ..
)

echo.
echo [1/2] Starting Backend Server (FastAPI on http://127.0.0.1:8000)...
start "CareerLens Backend" cmd /k "cd /d backend && set PYTHONPATH=. && venv\Scripts\python.exe -m uvicorn app.main:app --port 8000"

timeout /t 2 >nul

echo [2/2] Starting Frontend Server (Next.js on http://localhost:3000)...
start "CareerLens Frontend" cmd /k "cd /d frontend && npm run dev"

echo.
echo =====================================================================
echo    Both servers launched successfully!
echo    Frontend: http://localhost:3000
echo    Backend API Docs: http://127.0.0.1:8000/docs
echo =====================================================================
pause
